package ValueObject;

import java.util.Scanner;

public class VHeader {
	private String header;
	
	
	public void setHeader(String header) {
		this.header = header;
	}
	public String getHeader() {
		return this.header;
	}
}

